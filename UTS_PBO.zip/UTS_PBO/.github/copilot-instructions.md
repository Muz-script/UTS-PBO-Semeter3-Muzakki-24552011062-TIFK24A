## Quick orientation

This repository is a small Java classroom domain model used as a demo/exercise. Key source files live in the repository root:

- `Main.java` — application entry point; constructs domain objects and demonstrates interactions.
- `User.java` — base class for people (contains validation in setters and `tampilkanInfo`).
- `Mahasiswa.java`, `Dosen.java` — extend `User` and add domain-specific fields and methods (`ambilMataKuliah`, `mengajar`).
- `MataKuliah.java` — simple value object for course data.

Design notes an AI helper should follow

- Single-class-per-file, PascalCase filenames matching class names (e.g., `Mahasiswa.java` contains `public class Mahasiswa`).
- Fields are `private` with public getters/setters. Validation is implemented in setters and reports errors via `System.out.println` (no exceptions). Preserve this pattern when adding features to stay consistent.
- Identifier formats are enforced with regexes in setters:
  - `Mahasiswa.nim` expects format `M[digits]` (see `setNim`).
  - `Dosen.nidn` expects `D[digits]` (see `setNidn`).
  - `MataKuliah.kode` expects `MK[digits]` (see `setKode`).

How to run and debug locally (Windows PowerShell)

1. Compile all sources from repo root:

```powershell
javac *.java
```

2. Run the demo app:

```powershell
java Main
```

`Main.java` shows typical usage: it creates `MataKuliah`, `Mahasiswa`, and `Dosen` objects then calls `tampilkanInfo`, `ambilMataKuliah`, and `mengajar`. Use it as a test harness when iterating.

Code style & small conventions to follow in edits

- Keep validations in setters and use `System.out.println` for user-facing error messages (do not change to exceptions without a clear reason).
- Prefer adding small helper methods into the appropriate class (e.g., helper printing into `User` or domain classes) instead of creating utility classes for this small codebase.
- Keep public API surface small: expose behavior via methods (e.g., `ambilMataKuliah`, `mengajar`) rather than letting external code manipulate fields directly.

Integration and external dependencies

- There are no external libraries or build tools (Maven/Gradle). The project is compiled and run with `javac`/`java` as shown above.

Examples to reference when making changes

- Creating and using objects (from `Main.java`):

  MataKuliah mk1 = new MataKuliah("MK001", "Pemrograman Berorientasi Objek", 3);
  Mahasiswa m1 = new Mahasiswa("Muzakki", "Muzakki@gmail.com", "Bandung", "081234567890", "M24552011062", "Informatika", 3.75);
  m1.ambilMataKuliah(mk1);

When updating the code, ensure new tests/examples use the same constructor signatures and call patterns so the demo in `Main` continues to work.

If something isn't discoverable here (tests, CI, or project goals), ask the repository owner for intended grading/running steps before making larger structural changes.

— End of instructions —
