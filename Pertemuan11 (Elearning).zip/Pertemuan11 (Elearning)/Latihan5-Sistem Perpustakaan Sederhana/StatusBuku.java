public enum StatusBuku {
    TERSEDIA,
    DIPINJAM
}
